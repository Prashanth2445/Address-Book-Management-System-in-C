#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

// color codes
#define RESET "\033[0m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define CYAN "\033[36m"
#define RB "\033[1;31m"
#define GB "\033[1;32m"
#define CB "\033[1;36m"
#define YB "\033[1;33m"

int i, count, len, j = 0;
int value = 0;

char name[20];  // tempervary string to store a name
char phone[20]; // tempervary string to store a phone
char email[50]; // tempervary string to store a email

void listContacts(AddressBook *addressBook, int sortlist)
{
    Contact sortemp; // temp structure of same size of contact structure

    if (addressBook->contactCount == 0) // if contactcount is 0 no contact is saved
    {
        printf(RED "\n----------------------------------------------------\n");
        printf("\t:::::::✘ No contacts saved:::::::\n");
        printf("----------------------------------------------------\n" RESET);
        return;
    }

    // sorting logic;
    for (j = 0; j < addressBook->contactCount - 1; j++)
    {
        for (int i = 0; i < addressBook->contactCount - 1 - j; i++)
        {
            int temp = 0; // temp for collecting the strcasecmp return value
            if (sortlist == 1)
            {
                temp = strcasecmp(addressBook->contacts[i].name, addressBook->contacts[i + 1].name); // sorting by name
            }
            else if (sortlist == 2)
            {
                temp = strcasecmp(addressBook->contacts[i].phone, addressBook->contacts[i + 1].phone); //// sorting by phone number
            }
            else if (sortlist == 3)
            {
                temp = strcasecmp(addressBook->contacts[i].email, addressBook->contacts[i + 1].email); // sorting by email
            }
            if (temp > 0)
            {
                sortemp = addressBook->contacts[i];                      // copy contact structure to temp structure
                addressBook->contacts[i] = addressBook->contacts[i + 1]; // copy contact structure of i+1  to contact structure of i
                addressBook->contacts[i + 1] = sortemp;                  // copy temp structure to contact structure of i+1
            }
        }
    }

    // choice=addressBook->contactCount;
    printf(GB "\nList of the Total Contacts saved\n" RESET);
    printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
    printf("--------------------------------------------------------------------\n" RESET);
    int i;
    for (i = 0; i < addressBook->contactCount; i++)
    {
        printf("%-6d %-15s %-15s %-30s\n", i + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }
    printf(GREEN "--------------------------------------------------------------------\n");
    printf("Total contacts: %d\n", i);
    printf("--------------------------------------------------------------------\n" RESET);
}

void initialize(AddressBook *addressBook)
{
    //  populateAddressBook(addressBook);
    loadContactsFromFile(addressBook);
    // Load contacts from file during initialization (After files)
}

void saveAndExit(AddressBook *addressBook)
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS);              // Exit the program
}

void createContact(AddressBook *addressBook)
{
    /* Define the logic to create a Contacts */
    // Reading the name and validating it with lawercase, uppercase, ans space.
    do
    {
        printf(CYAN "✍ Enter the name:");
        scanf(" %19[^\n]", name);
        RESET;
        if (name_validation(name)) // funtion call for validation name while creating contact
        {
            break;
        }
    } while (1);

    // Entering the phone number and validating it with digit only 10
    do
    {

        printf(CYAN "Enter the phone 📞 number: ");
        scanf(" %19[^\n]", phone);
        RESET;
        if (phone_validation(phone, addressBook))
        {
            break;
        }
    } while (1); // condition .count != 10

    do // Reading E-mail
    {

        printf(CYAN "Enter the Gmail 📩: ");
        scanf(" %19[^\n]", email);
        RESET;
        if (email_validation(email, addressBook)) // function call validating it with lowercase, digit, @, _, and .
        {
            break;
        }
    } while (1);

    // copy the name phone no, email after the all validation
    strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
    strcpy(addressBook->contacts[addressBook->contactCount].email, email);
    addressBook->contactCount++; // contactCount index increment
}

void searchContact(AddressBook *addressBook)
{
    /* Define the logic for search */
    int search, slno, j;
    char searchame[20];
    char *result;
    do
    {
        printf(CB "\n🔍 Search by:\n" RESET);
        printf(YELLOW "1. Name ✍ \n");
        printf("2. Phone number 📞\n");
        printf("3. E-mail 📩\n");
        printf("4. Exit ↩\n");
        printf("Enter your choice: ");
        scanf("%d", &search);
        RESET;
        switch (search)
        {
            // search with a name case
        case 1:
            do
            {
                printf(CYAN "✍ Enter a name: ");
                scanf(" %19[^\n]", name);
                RESET;
                if (name_validation(name)) // name validation function call for searching contact
                {
                    break;
                }
            } while (1);
            // logic for print the searched names;
            int res = 0;
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {
                result = strstr(addressBook->contacts[i].name, name);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by name\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✘ No contact found with the given name:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contact found with Name: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }
            break;

            // search with a phone number case
        case 2:
            do
            {
                printf(CYAN "Enter a phone 📞 number: ");
                scanf(" %19[^\n]", phone);
                RESET;
                len = strlen(phone);
                j = 0;
                for (i = 0; i < len; i++) //// phone validation function call for searching contact
                {
                    if (isdigit(phone[i]))
                    {
                        j++;
                    }
                }
                if (j == len)
                {
                    break;
                }
            } while (1);

            // logic for print the searched contacts with phone number
            res = 0;
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {
                result = strstr(addressBook->contacts[i].phone, phone);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by phone number\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("   :::::::✘ No contact found with the given phone number:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contact found with phone number: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }
            break;

            // search with a Email case
        case 3:
            do
            {
                printf(CYAN "Enter a Gmail 📩: ");
                scanf(" %49[^\n]", email);
                RESET;
                len = strlen(email);
                j = 0;
                for (i = 0; i < len; i++)
                {
                    if ((islower(email[i])) || (isdigit(email[i])) || (email[i] == '@') || (email[i] == '_') || (email[i] == '.'))
                    {
                        j++;
                    }
                }
                int flag = 0;
                int flag1 = 0;
                char com[] = ".com";
                char *k = strstr(email, com);
                for (i = 0; i < len; i++)
                {
                    if (email[i] == '@') // check before @ name is present or not, if true flag > 0;
                    {
                        flag = i;
                    }
                    if (email[i] == '.')
                    {
                        flag1 = i;
                    }
                }
                if (j == len) // email validation function call for searching contact
                {
                    if (k != NULL && flag != 0 && flag1 != flag + 1)
                    {
                        printf(GREEN "✔ E-mail is Validated: %s\n" RESET, email);
                        break;
                    }
                    else
                    {
                        printf(RED "\n:::::::✘ Entered Gmail is invalid Re-enter:::::::\n" RESET);
                    }
                }
                else
                {
                    printf(RED "\n:::::::✘ Entered Gmail is invalid Re-enter:::::::\n" RESET);
                }

            } while (1);

            // logic for print the searched contact by email
            res = 0;
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {
                result = strstr(addressBook->contacts[i].email, email);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by email\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✘ No contact found with the given Email:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contact found with E-mail: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }

            break;
        case 4:
            printf(CB "\n<< Back \n" RESET);
            break;

        default:
            printf(RED "⚠ Enter the valid choice\n" RESET);
            break;
        }
    } while (search != 4);
}

void editContact(AddressBook *addressBook)
{
    /* Define the logic for Editcontact */
    int edit, num, valid;
    do
    {
        printf(CB "\n🖊 Edit by:\n" RESET);
        printf(YELLOW "1. Name ✍ \n");
        printf("2. Phone number 📞\n");
        printf("3. E-mail 📩\n");
        printf("4. Exit ↩\n");
        printf("Enter your choice: ");
        scanf("%d", &edit);
        RESET;
        // list all contacts
        listContacts(addressBook, edit);

        switch (edit)
        {
        case 1:
            printf("Enter the serial number for Editing: ");
            scanf("%d", &num);
            do
            {
                valid = 0;
                printf(CYAN "Enter new name ✍: ");
                scanf(" %19[^\n]", name);
                RESET;
                if (name_validation(name)) // funtion call for validation name while creating contact
                {
                    printf(GREEN "\n✔ Name is Editied Successfully\n" RESET);
                    strcpy(addressBook->contacts[num - 1].name, name); // copy the new name to addressBook structure name
                    valid = 1;
                }
            } while (!valid);
            break;
        case 2:

            printf("Enter the serial number for Editing: ");
            scanf("%d", &num);
            do
            {
                valid = 0;
                printf(CYAN "Enter new Phone 📞 number: ");
                scanf(" %19[^\n]", phone);
                RESET;
                if (phone_validation(phone, addressBook)) // funtion call for validation name while creating contact
                {
                    printf(GREEN "\n✔ Phone number is Editied Successfully\n" RESET);
                    strcpy(addressBook->contacts[num - 1].phone, phone); // copy the new phone number to addressBook structure phone
                    valid = 1;
                }
            } while (!valid);
            break;

        case 3:
            printf("Enter the serial number for Editing: ");
            scanf("%d", &num);
            do
            {
                valid = 0;
                printf(CYAN "Enter new 📩 E-mail: ");
                scanf(" %19[^\n]", email);
                RESET;
                if (email_validation(email, addressBook)) // funtion call for validation name while creating contact
                {
                    printf(GREEN "\n✔ Email is Editied Successfully \n" RESET);
                    strcpy(addressBook->contacts[num - 1].email, email); // copy the new email to addressBook structure email
                    valid = 1;
                }
            } while (!valid);
            break;

        case 4:
            printf(CB "\n<< Back \n" RESET);
            break;

        default:
            printf(RED "\n:::::::⚠ Enter the valid choice:::::::\n" RESET);
            break;
        }
    } while (edit != 4);
}

void deleteContact(AddressBook *addressBook)
{
    /* Define the logic for deletecontact */
    int delete, slno, j, remove;
    char searchame[20];
    char *result;
    do
    {
        printf(CB "\n🗑 Delete by:\n" RESET);
        printf(YELLOW "1. Name ✍\n");
        printf("2. Phone number 📞\n");
        printf("3. E-mail 📩\n");
        printf("4. Exit ↩\n");
        printf("Enter your choice: ");
        scanf("%d", &delete);
        RESET;
        switch (delete)
        {
            // search with a name case
        case 1:
            do
            {
                printf(CYAN "Enter a name ✍: ");
                scanf(" %19[^\n]", name);
                RESET;
                if (name_validation(name)) // name validation function call for searching contact
                {
                    break;
                }
            } while (1);
            // logic for print the searched names;
            int res = 0;
            int match[100];
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {

                result = strstr(addressBook->contacts[i].name, name);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by name\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    // printf("%d\n",addressBook->contactCount);
                    match[slno - 1] = i;
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✘ No contact found with the given name:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contacts found with given name: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }
            if (res)
            {
                do
                {
                    printf("Enter the serial no for delete: ");
                    scanf("%d", &remove);
                    if (remove < 1 || remove >= slno)
                    {
                        printf(RED "⚠ Invalid choice!\n" RESET);
                    }
                    else
                    {
                        break;
                    }
                } while (1);
                int index = match[remove - 1];
                for (i = index; i < addressBook->contactCount - 1; i++)
                {
                    addressBook->contacts[i] = addressBook->contacts[i + 1];
                }
                addressBook->contactCount--;
                printf(GREEN "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✔ Contact deleted 🗑 Successfully:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            break;

            // search with a phone number case
        case 2:
            do
            {

                printf(CYAN "Enter a phone 📞 number: ");
                scanf(" %19[^\n]", phone);
                RESET;
                len = strlen(phone);
                j = 0;
                for (i = 0; i < len; i++) //// phone validation function call for searching contact
                {
                    if (isdigit(phone[i]))
                    {
                        j++;
                    }
                }
                if (j == len)
                {
                    break;
                }
            } while (1);

            // logic for print the searched contacts with phone number
            res = 0;
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {
                result = strstr(addressBook->contacts[i].phone, phone);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by phone number\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "Email ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    match[slno - 1] = i;
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✘ No contact found with the given phone number:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contacts found with given name: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }
            if (res)
            {
                do
                {
                    printf("Enter the serial no for delete: ");
                    scanf("%d", &remove);
                    if (remove < 1 || remove >= slno)
                    {
                        printf(RED "⚠ Invalid choice!\n" RESET);
                    }
                    else
                    {
                        break;
                    }
                } while (1);
                int index = match[remove - 1];
                for (i = index; i < addressBook->contactCount - 1; i++)
                {
                    addressBook->contacts[i] = addressBook->contacts[i + 1];
                }
                addressBook->contactCount--;
                printf(GREEN "\n------------------------------------------------------------------------\n");
                printf("\t\t:::::::✔ Contact deleted 🗑 Successfully:::::::\n");
                printf("------------------------------------------------------------------------\n" RESET);
            }
            break;

            // search with a Email case
        case 3:
            do
            {

                printf(CYAN "Enter a E-mail 📩: ");
                scanf(" %49[^\n]", email);
                RESET;
                len = strlen(email);
                j = 0;
                for (i = 0; i < len; i++)
                {
                    if ((islower(email[i])) || (isdigit(email[i])) || (email[i] == '@') || (email[i] == '_') || (email[i] == '.'))
                    {
                        j++;
                    }
                }
                int flag = 0;
                int flag1 = 0;
                char com[] = ".com";
                char *k = strstr(email, com);
                for (i = 0; i < len; i++)
                {
                    if (email[i] == '@') // check before @ name is present or not, if true flag > 0;
                    {
                        flag = i;
                    }
                    if (email[i] == '.')
                    {
                        flag1 = i;
                    }
                }

                if (j == len) // email validation function call for searching contact
                {
                    if (k != NULL && flag != 0 && flag + 1 != flag1)
                    {
                        printf(GREEN "✔ E-mail is Validated: %s\n" RESET, email);
                        break;
                    }
                    else
                    {
                        printf(RED "\n:::::::✘ Entered E-mail is invalid Re-enter:::::::\n" RESET);
                    }
                }
                else
                {
                    printf(RED "\n:::::::✘ Entered E-mail is invalid Re-enter:::::::\n" RESET);
                }

            } while (1);
            // logic for print the searched
            res = 0;
            slno = 1;
            for (i = 0; i < addressBook->contactCount; i++)
            {
                result = strstr(addressBook->contacts[i].email, email);
                if (result != NULL)
                {
                    if (!res)
                    {
                        printf(GB "\nList of the contact searched by email\n" RESET);
                        printf(GREEN "Sl.No  %-15s %-15s %-30s\n", "Name", "Phone number", "E-mail ID");
                        printf("--------------------------------------------------------------------\n" RESET);
                    }
                    printf("%-6d %-15s %-15s %-30s\n", slno, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    match[slno - 1] = i;
                    slno++;
                    res = 1;
                }
            }
            if (!res)
            {
                printf(RED "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✘ No contact found with the given E-mail:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }
            else
            {
                printf(GREEN "--------------------------------------------------------------------\n");
                printf("Total contacts found with given name: %d\n", slno - 1);
                printf("--------------------------------------------------------------------\n" RESET);
            }
            if (res)
            {
                do
                {
                    printf("Enter the serial no for delete: ");
                    scanf("%d", &remove);
                    if (remove < 1 || remove >= slno)
                    {
                        printf(RED "⚠ Invalid choice!\n" RESET);
                    }
                    else
                    {
                        break;
                    }
                } while (1);
                int index = match[remove - 1];
                for (i = index; i < addressBook->contactCount - 1; i++)
                {
                    addressBook->contacts[i] = addressBook->contacts[i + 1];
                }
                addressBook->contactCount--;
                printf(GREEN "\n--------------------------------------------------------------------\n");
                printf("\t:::::::✔ Contact deleted Successfully:::::::\n");
                printf("--------------------------------------------------------------------\n" RESET);
            }

            break;
        case 4:
            printf(CB "\n<< Back \n" RESET);
            break;

        default:
            printf(RED "⚠ Enter the valid choice\n" RESET);
            break;
        }
    } while (delete != 4);
}

int name_validation(const char *name)
{
    count = 0;
    len = strlen(name); // name string length
    for (i = 0; i < len; i++)
    {
        if ((name[i] >= 'A' && name[i] <= 'Z') || (name[i] >= 'a' && name[i] <= 'z') || (name[i] == ' ') || (name[i] == '.')) // checking alpha, '.' and ' '
        {
            count++; // if valid character count++;
        }
    }
    if (len == count) // check for length is equal to count (if all characters are valid both is equal)
    {
        printf(GREEN "✔ Name is Validated: %s\n" RESET, name);
        return 1;
    }
    else
    {
        printf(RED "\n:::::::✘ Enterd name is invalid Re-enter:::::::\n" RESET);
        return 0;
    }
}

int phone_validation(const char *phone, AddressBook *addressBook)
{
    count = 0;
    len = strlen(phone); // phone number string length
    for (i = 0; i < len; i++)
    {
        if (phone[i] >= '0' && phone[i] <= '9') // Checking if its number or not if digit count++;
        {
            count++;
        }
        if (phone[0] == '0')
        {
            printf(RED "\n:::::::✘ Entered number is invalid Re-Enter:::::::\n" RESET);
            return 0;
        }
    }

    if (count == 10) // check the number is equal to 10 if true valid
    {
        int isunique = 1;
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone, phone) == 0)
            {
                isunique = 0;
                break;
            }
        }
        if (isunique)
        {
            printf(GREEN "✔ Phone number is Validated: %s\n" RESET, phone);
            return 1;
        }
        else
        {
            printf(RED "\n:::::::⚠ Phone number already exists, Re-Enter:::::::\n" RESET);
            return 0;
        }
    }
    else
    {
        printf(RED "\n:::::::✘ Entered number is invalid Re-Enter:::::::\n" RESET);
        return 0;
    }
}

int email_validation(const char *email, AddressBook *addressBook)
{
    count = 0;
    len = strlen(email); // gmail string length5
    for (i = 0; i < len; i++)
    {
        if ((email[i] >= 'a' && email[i] <= 'z') || (email[i] >= '0' && email[i] <= '9') || (email[i] == '@') || (email[i] == '_') || (email[i] == '.')) // checking condition a-z, 0-9 & @, _, .
        {
            count++; // if valid character is present count will be incremented
        }
    }
    if (count == len) // if count == len means all character is valid
    {
        char com[] = ".com";
        int flag = 0;
        int flag1 = 0;
        char *k = strstr(email, com); // check last .com is present are not
        for (i = 0; i < len; i++)
        {
            if (email[i] == '@') // check before @ name is present or not, if true flag > 0;
            {
                flag = i;
            }
            if (email[i] == '.')
            {
                flag1 = i;
            }
        }

        if (flag + 1 == flag1)
        {
            printf(RED "\n:::::::✘Entered E-mail is invalid Re-enter:::::::\n" RESET);
            return 0;
        }
        if (k != NULL) // return value of k is validating
        {
            if (flag == 0)
            {
                printf(RED "\n:::::::✘ Entered E-mail is invalid Re-enter:::::::\n" RESET);
                return 0;
            }
            else
            {
                int isunique = 1;
                for (i = 0; i < addressBook->contactCount; i++)
                {
                    if (strcmp(addressBook->contacts[i].email, email) == 0)
                    {
                        isunique = 0;
                        break;
                    }
                }
                if (isunique)
                {
                    printf(GREEN "E-mail is Validated: %s\n" RESET, email);
                    return 1;
                }
                else
                {
                    printf(RED "\n:::::::⚠ E-mail is already exists, Re-enter:::::::\n" RESET);
                    return 0;
                }
            }
        }
        else
        {
            printf(RED "\n:::::::✘ Entered E-mail is invalid Re-enter:::::::\n" RESET);
            return 0;
        }
    }
    else
    {
        printf(RED "\n:::::::✘ Entered E-mail is invalid Re-enter:::::::\n" RESET);
        return 0;
    }
}