/*
NAME:PRASHANTH REDDY
BATCH : 25021A
DATE:25-09-2025
DESCRIPTION:This program is about  an address book system project.
            It can create contacts with validated Name,Phone,and Email.
            It can list all contacts sorted by name,phone or email.
            It can search contacts by any field, name phone number, email.
            It can edit selected contact details.
            It can delete contacts which is selected.
            save all changes to a file before exit.
            The  program IS implemented using strings pointers,functions,structures ,files and basic of c.
            the command promt messages is prints in different colors
            warning and error commands prints in red color
            correct, validated and successfull are printed in green color;
*/

#include <stdio.h>
#include "contact.h"
/// TO PRINT IN COLORS
#define RESET "\033[0m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define CYAN "\033[36m"
#define RB "\033[1;31m"
#define GB "\033[1;32m"
#define CB "\033[1;36m"
#define YB "\033[1;33m"

int main()
{
    int choice, sortlist;
    AddressBook addressBook;
    addressBook.contactCount = 0;
    // loadContactsFromFile(&addressBook);
    initialize(&addressBook); // Initialize the address book

    do
    {
        printf(GB "\n 📒 Address Book Menu ☰\n" RESET);
        printf("1. ➕ Create contact\n");
        printf("2. 🔍 Search contact\n");
        printf("3.  🖊 Edit contact\n");
        printf("4.  🗑 Delete contact\n");
        printf("5. 📋 List all contacts\n");
        printf("6. 💾 Save contacts\n");
        printf("7.  ↩ Exit \n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            createContact(&addressBook);
            break;
        case 2:
            searchContact(&addressBook);
            break;
        case 3:
            editContact(&addressBook);
            break;
        case 4:
            deleteContact(&addressBook);
            break;
        case 5:
            do
            {
                printf(CB "\nEnter a number to sort contacts by\n" RESET);
                printf(YELLOW "1. Name\n");
                printf("2. Phone number\n");
                printf("3. Email ID\n");
                printf("Enter the choice: ");
                scanf("%d", &sortlist);
                RESET;
                if (sortlist < 4 && sortlist > 0)
                {
                    break;
                }
                else
                {
                    printf(RED "\n⚠ Invalid choice. Please enter a valid number from 1 to 3\n" RESET);
                }
            } while (1);

            listContacts(&addressBook, sortlist);
            break;
        case 6:
            printf(GREEN "\nSaving and Exiting.....⏳\n" RESET);
            saveContactsToFile(&addressBook);
            break;
        case 7:
            printf(RB "Exiting the Addressbook program....⏳\n" RESET);
            break;
        default:
            printf(RED "⚠ Invalid choice. Please try again.\n" RESET);
        }
    } while (choice != 7);

    return 0;
}
