#include <stdio.h>
#include "file.h"

// PRINT COLORS
#define RESET "\033[0m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define CYAN "\033[36m"
#define RB "\033[1;31m"
#define GB "\033[1;32m"
#define CB "\033[1;36m"
#define YB "\033[1;33m"

void saveContactsToFile(AddressBook *addressBook)
{
    int i;
    FILE *fp;
    fp = fopen("contact.csv", "w");
    if (fp == NULL)
    {
        addressBook->contactCount = 0;
        return;
    }

    fprintf(fp, "%d\n", addressBook->contactCount);

    for (i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fp, "%s,%s,%s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }
    fclose(fp);
    printf(GB "\nContact saved Successfully ✅\n" RESET);
}

void loadContactsFromFile(AddressBook *addressBook)
{
    int i;
    FILE *fp;
    fp = fopen("contact.csv", "r");
    if (fp == NULL)
    {
        return;
    }
    fscanf(fp, "%d\n", &addressBook->contactCount);

    for (i = 0; i < addressBook->contactCount; i++)
    {
        fscanf(fp, "%[^,],%[^,],%[^\n]\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }
    fclose(fp);
    // loadContactsFromFile(addressBook);
}
